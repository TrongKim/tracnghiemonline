export interface IClass {
    admin_id: number;
    ma_lop: number;
    ten_lop: string;
    ten_dang_nhap: string;
    ma_vao_lop: string;
}

export interface ICreateClass {
    class_name: string;
    description: string;
}