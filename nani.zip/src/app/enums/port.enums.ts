export const API_HOST = 'http://localhost:3567/api/';
// export const API_HOST = 'https://tracnghiemonline.info/api/';